from cave_utils import Socket

Socket()
