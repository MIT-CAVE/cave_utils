from cave_utils.utils import Socket

Socket()