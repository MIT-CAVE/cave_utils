from cave_utils.socket import Socket

Socket()